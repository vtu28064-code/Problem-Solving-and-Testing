import java.util.Scanner;

public class Task3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Read the number of days
        int N = sc.nextInt();

        int[] profit = new int[N];

        // Read daily profit/loss values
        for (int i = 0; i < N; i++) {
            profit[i] = sc.nextInt();
        }

        // Initialize Kadane's variables
        int maxEndingHere = profit[0];
        int maxSoFar = profit[0];

        // Apply Kadane's Algorithm
        for (int i = 1; i < N; i++) {

            maxEndingHere = Math.max(profit[i], maxEndingHere + profit[i]);

            maxSoFar = Math.max(maxSoFar, maxEndingHere);
        }

        // Print the maximum profit
        System.out.println(maxSoFar);

        sc.close();
    }
}